package com.drool.DroolKiSession;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.rule.FactHandle;

public class DroolTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DroolTest dt = new DroolTest();
		dt.executeLogic();

	}
	
	public void executeLogic() {
		try {
			KieServices ks =  KieServices.Factory.get();
			KieContainer kContainer = ks.getKieClasspathContainer();
			KieSession kSession = kContainer.newKieSession("first-ksession-rule");
			
			PaymentOffer paymentOffer = new PaymentOffer();
			paymentOffer.setChannel("paytm");
			paymentOffer.setFestival("diwali");
			//paymentOffer.setFirstTimeCustomer(true);
			
			FactHandle factHandle;
			factHandle = kSession.insert(paymentOffer);
			
			kSession.fireAllRules();
			
			System.out.println("The Cashback for this payment channel VIA Kie "+paymentOffer.getChannel()+ " is ->"+paymentOffer.getDiscount());
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
